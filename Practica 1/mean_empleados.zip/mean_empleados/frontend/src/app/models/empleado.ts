export interface Empleado { 
    nombre          : string 
    cargo           : string 
    departamento    : string 
    sueldo          : Number 
    createdAt?      : string 
    updatedAt?      : string 
    _id?            : string 
}